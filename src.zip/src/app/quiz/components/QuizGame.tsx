"use client"
import { useState, useEffect } from "react"
import { Brain, Clock, CheckCircle, XCircle, Trophy, Star, ArrowRight, RotateCcw } from "lucide-react"

interface QuizQuestion {
  id: number
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  difficulty: "Mudah" | "Sedang" | "Sulit"
  category: string
  points: number
}

const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "Berapa lama waktu yang dibutuhkan botol plastik untuk terurai secara alami?",
    options: ["50-100 tahun", "200-300 tahun", "450-1000 tahun", "1500-2000 tahun"],
    correctAnswer: 2,
    explanation:
      "Botol plastik membutuhkan waktu 450-1000 tahun untuk terurai secara alami, itulah mengapa daur ulang sangat penting!",
    difficulty: "Mudah",
    category: "Pengetahuan Dasar",
    points: 10,
  },
  {
    id: 2,
    question: "Apa yang dimaksud dengan prinsip 3R dalam pengelolaan sampah?",
    options: ["Recycle, Reuse, Reduce", "Reduce, Reuse, Recycle", "Reuse, Reduce, Recycle", "Reduce, Recycle, Reuse"],
    correctAnswer: 1,
    explanation:
      "Prinsip 3R adalah Reduce (mengurangi), Reuse (menggunakan kembali), dan Recycle (mendaur ulang) - dalam urutan prioritas tersebut!",
    difficulty: "Mudah",
    category: "Pengetahuan Dasar",
    points: 10,
  },
  {
    id: 3,
    question: "Sampah organik yang paling cocok untuk dijadikan kompos adalah:",
    options: ["Sisa makanan berminyak", "Kulit buah dan sayuran", "Tulang ayam dan ikan", "Daun yang sudah busuk"],
    correctAnswer: 1,
    explanation:
      "Kulit buah dan sayuran adalah bahan terbaik untuk kompos karena mudah terurai dan kaya nutrisi untuk tanaman.",
    difficulty: "Sedang",
    category: "Pengolahan Sampah",
    points: 15,
  },
  {
    id: 4,
    question: "Manakah yang BUKAN termasuk sampah B3 (Bahan Berbahaya dan Beracun)?",
    options: ["Baterai bekas", "Lampu neon", "Botol kaca bekas", "Obat kedaluwarsa"],
    correctAnswer: 2,
    explanation: "Botol kaca bekas bukan sampah B3, melainkan sampah anorganik yang dapat didaur ulang dengan aman.",
    difficulty: "Sedang",
    category: "Jenis Sampah",
    points: 15,
  },
  {
    id: 5,
    question: "Berapa persen sampah di Indonesia yang berhasil didaur ulang?",
    options: ["Sekitar 5-10%", "Sekitar 15-20%", "Sekitar 25-30%", "Sekitar 35-40%"],
    correctAnswer: 0,
    explanation:
      "Sayangnya, hanya sekitar 5-10% sampah di Indonesia yang berhasil didaur ulang. Masih banyak ruang untuk perbaikan!",
    difficulty: "Sulit",
    category: "Statistik Lingkungan",
    points: 20,
  },
]

export default function QuizGame() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(30)
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [correctAnswers, setCorrectAnswers] = useState(0)
  const [isAnswered, setIsAnswered] = useState(false)

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0 && !showResult && !quizCompleted) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !isAnswered) {
      handleTimeUp()
    }
  }, [timeLeft, showResult, quizCompleted, isAnswered])

  const handleTimeUp = () => {
    setIsAnswered(true)
    setShowResult(true)
    setTimeout(() => {
      nextQuestion()
    }, 3000)
  }

  const handleAnswerSelect = (answerIndex: number) => {
    if (isAnswered) return

    setSelectedAnswer(answerIndex)
    setIsAnswered(true)
    setShowResult(true)

    const currentQ = quizQuestions[currentQuestion]
    if (answerIndex === currentQ.correctAnswer) {
      setScore(score + currentQ.points)
      setCorrectAnswers(correctAnswers + 1)
    }

    setTimeout(() => {
      nextQuestion()
    }, 3000)
  }

  const nextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setShowResult(false)
      setTimeLeft(30)
      setIsAnswered(false)
    } else {
      setQuizCompleted(true)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
    setTimeLeft(30)
    setQuizCompleted(false)
    setCorrectAnswers(0)
    setIsAnswered(false)
  }

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      Mudah: "bg-green-100 text-green-700 border-green-200",
      Sedang: "bg-yellow-100 text-yellow-700 border-yellow-200",
      Sulit: "bg-red-100 text-red-700 border-red-200",
    }
    return colors[difficulty as keyof typeof colors]
  }

  const getScoreGrade = () => {
    const percentage = (correctAnswers / quizQuestions.length) * 100
    if (percentage >= 80) return { grade: "A", color: "text-green-600", message: "Luar Biasa!" }
    if (percentage >= 60) return { grade: "B", color: "text-blue-600", message: "Bagus!" }
    if (percentage >= 40) return { grade: "C", color: "text-yellow-600", message: "Cukup Baik" }
    return { grade: "D", color: "text-red-600", message: "Perlu Belajar Lagi" }
  }

  if (quizCompleted) {
    const gradeInfo = getScoreGrade()
    return (
      <section className="w-full py-20 px-4 bg-gradient-to-br from-purple-50 to-indigo-50">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-200 text-center">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-12 h-12 text-white" />
            </div>

            <h2 className="text-3xl font-bold text-gray-800 mb-4">Quiz Selesai! 🎉</h2>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl p-6">
                <div className="text-3xl font-bold text-blue-600 mb-2">{score}</div>
                <div className="text-sm text-blue-700">Total Poin</div>
              </div>

              <div className="bg-gradient-to-br from-green-100 to-green-200 rounded-2xl p-6">
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {correctAnswers}/{quizQuestions.length}
                </div>
                <div className="text-sm text-green-700">Jawaban Benar</div>
              </div>

              <div className="bg-gradient-to-br from-purple-100 to-purple-200 rounded-2xl p-6">
                <div className={`text-3xl font-bold mb-2 ${gradeInfo.color}`}>{gradeInfo.grade}</div>
                <div className="text-sm text-purple-700">{gradeInfo.message}</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={resetQuiz}
                className="bg-purple-500 text-white px-8 py-3 rounded-full font-medium hover:bg-purple-600 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Coba Lagi
              </button>

              <button className="border-2 border-purple-500 text-purple-500 px-8 py-3 rounded-full font-medium hover:bg-purple-50 transition-all duration-300 hover:scale-105">
                Bagikan Hasil
              </button>
            </div>
          </div>
        </div>
      </section>
    )
  }

  const currentQ = quizQuestions[currentQuestion]

  return (
    <section className="w-full py-20 px-4 bg-gradient-to-br from-purple-50 to-indigo-50">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-purple-100 px-4 py-2 rounded-full mb-6">
            <Brain className="w-5 h-5 text-purple-600 animate-pulse" />
            <span className="text-purple-700 font-medium text-sm">Quiz Challenge</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 leading-tight">
            Test <span className="text-purple-600">Pengetahuan</span> Sampah
          </h1>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Uji seberapa dalam pemahamanmu tentang pengelolaan sampah dan lingkungan!
          </p>
        </div>

        {/* Quiz Progress */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-gray-600">
                Pertanyaan {currentQuestion + 1} dari {quizQuestions.length}
              </span>
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(currentQ.difficulty)}`}
              >
                {currentQ.difficulty}
              </span>
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium border border-purple-200">
                {currentQ.category}
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-500" />
                <span className="font-bold text-gray-800">{score} poin</span>
              </div>

              <div className={`flex items-center gap-2 ${timeLeft <= 10 ? "text-red-600" : "text-gray-600"}`}>
                <Clock className="w-4 h-4" />
                <span className="font-bold">{timeLeft}s</span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-purple-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-200 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-8 leading-relaxed">{currentQ.question}</h2>

          {/* Answer Options */}
          <div className="grid gap-4">
            {currentQ.options.map((option, index) => {
              let buttonClass = "w-full text-left p-6 rounded-2xl border-2 transition-all duration-300 font-medium"

              if (!showResult) {
                buttonClass += " border-gray-200 hover:border-purple-300 hover:bg-purple-50 cursor-pointer"
              } else {
                if (index === currentQ.correctAnswer) {
                  buttonClass += " border-green-300 bg-green-50 text-green-700"
                } else if (index === selectedAnswer && selectedAnswer !== currentQ.correctAnswer) {
                  buttonClass += " border-red-300 bg-red-50 text-red-700"
                } else {
                  buttonClass += " border-gray-200 bg-gray-50 text-gray-500"
                }
              }

              return (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  disabled={isAnswered}
                  className={buttonClass}
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        showResult && index === currentQ.correctAnswer
                          ? "bg-green-500 text-white"
                          : showResult && index === selectedAnswer && selectedAnswer !== currentQ.correctAnswer
                            ? "bg-red-500 text-white"
                            : "bg-gray-200 text-gray-600"
                      }`}
                    >
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="flex-1">{option}</span>
                    {showResult && index === currentQ.correctAnswer && (
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    )}
                    {showResult && index === selectedAnswer && selectedAnswer !== currentQ.correctAnswer && (
                      <XCircle className="w-6 h-6 text-red-500" />
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          {/* Explanation */}
          {showResult && (
            <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-2xl">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Brain className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-blue-700 mb-2">Penjelasan:</h4>
                  <p className="text-blue-600 leading-relaxed">{currentQ.explanation}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Timer Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
          <div
            className={`h-2 rounded-full transition-all duration-1000 ${
              timeLeft <= 10 ? "bg-red-500" : "bg-purple-500"
            }`}
            style={{ width: `${(timeLeft / 30) * 100}%` }}
          ></div>
        </div>

        {/* Next Button (only show if answered) */}
        {isAnswered && !quizCompleted && (
          <div className="text-center">
            <button
              onClick={nextQuestion}
              className="bg-purple-500 text-white px-8 py-3 rounded-full font-medium hover:bg-purple-600 transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2 mx-auto"
            >
              <span>{currentQuestion < quizQuestions.length - 1 ? "Pertanyaan Selanjutnya" : "Lihat Hasil"}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </section>
  )
}

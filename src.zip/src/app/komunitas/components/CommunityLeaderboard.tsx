"use client";
import { useState } from "react";
import {
  Trophy,
  Medal,
  Crown,
  Star,
  TrendingUp,
  Award,
  Users,
  Target,
  Zap,
} from "lucide-react";

interface LeaderboardUser {
  id: number;
  rank: number;
  name: string;
  avatar: string;
  points: number;
  level: number;
  badges: string[];
  streak: number;
  completedChallenges: number;
  joinDate: string;
  isCurrentUser?: boolean;
}

const leaderboardData: LeaderboardUser[] = [
  {
    id: 1,
    rank: 1,
    name: "Sarah Eco Warrior",
    avatar: "https://i.pravatar.cc/150?img=1",
    points: 15420,
    level: 25,
    badges: ["🏆", "🌱", "♻️", "🌟"],
    streak: 45,
    completedChallenges: 28,
    joinDate: "Jan 2024",
  },
  {
    id: 2,
    rank: 2,
    name: "Budi Green Master",
    avatar: "https://i.pravatar.cc/150?img=3",
    points: 14890,
    level: 24,
    badges: ["🥈", "🌿", "🔋", "💚"],
    streak: 38,
    completedChallenges: 25,
    joinDate: "Feb 2024",
  },
  {
    id: 3,
    rank: 3,
    name: "Rina Sustainability",
    avatar: "https://i.pravatar.cc/150?img=9",
    points: 13750,
    level: 22,
    badges: ["🥉", "🌍", "🌱", "⭐"],
    streak: 32,
    completedChallenges: 22,
    joinDate: "Jan 2024",
  },
  {
    id: 4,
    rank: 4,
    name: "Andi Zero Waste",
    avatar: "https://i.pravatar.cc/150?img=7",
    points: 12340,
    level: 20,
    badges: ["🌟", "♻️", "🌿"],
    streak: 28,
    completedChallenges: 19,
    joinDate: "Mar 2024",
  },
  {
    id: 5,
    rank: 5,
    name: "Kamu",
    avatar: "https://i.pravatar.cc/150?img=5",
    points: 8750,
    level: 15,
    badges: ["🌱", "♻️"],
    streak: 15,
    completedChallenges: 12,
    joinDate: "Apr 2024",
    isCurrentUser: true,
  },
];

const achievements = [
  {
    title: "Top Contributor",
    description: "Member dengan kontribusi terbanyak bulan ini",
    icon: "👑",
    winner: "Sarah Eco Warrior",
    points: "2,450 poin",
  },
  {
    title: "Challenge Master",
    description: "Menyelesaikan tantangan terbanyak",
    icon: "🏆",
    winner: "Budi Green Master",
    points: "28 tantangan",
  },
  {
    title: "Streak Champion",
    description: "Aktivitas harian terpanjang",
    icon: "🔥",
    winner: "Sarah Eco Warrior",
    points: "45 hari",
  },
];

// Helper function to format numbers consistently
const formatNumber = (num: number): string => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

export default function CommunityLeaderboard() {
  const [activeTab, setActiveTab] = useState<"monthly" | "weekly" | "alltime">(
    "monthly"
  );
  const [hoveredUser, setHoveredUser] = useState<number | null>(null);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return (
          <span className="w-6 h-6 flex items-center justify-center text-gray-600 font-bold">
            {rank}
          </span>
        );
    }
  };

  const getRankBg = (rank: number, isCurrentUser?: boolean) => {
    if (isCurrentUser) {
      return "bg-gradient-to-r from-blue-100 to-indigo-100 border-blue-300";
    }
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-yellow-100 to-amber-100 border-yellow-300";
      case 2:
        return "bg-gradient-to-r from-gray-100 to-slate-100 border-gray-300";
      case 3:
        return "bg-gradient-to-r from-amber-100 to-orange-100 border-amber-300";
      default:
        return "bg-white border-gray-200";
    }
  };

  return (
    <section className="w-full py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-100 px-4 py-2 rounded-full mb-6">
            <Trophy className="w-5 h-5 text-blue-600 animate-pulse" />
            <span className="text-blue-700 font-medium text-sm">
              Leaderboard
            </span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 leading-tight">
            Papan <span className="text-blue-600">Peringkat</span>
          </h1>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed mb-8">
            Lihat siapa yang paling aktif dan berprestasi dalam komunitas kita!
            Raih poin dan naik peringkat dengan berpartisipasi aktif.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-2xl p-2 shadow-sm border border-gray-200">
            <div className="flex gap-2">
              {[
                { id: "monthly", label: "Bulan Ini", icon: TrendingUp },
                { id: "weekly", label: "Minggu Ini", icon: Zap },
                { id: "alltime", label: "Sepanjang Masa", icon: Crown },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                      activeTab === tab.id
                        ? "bg-blue-500 text-white shadow-lg"
                        : "text-gray-600 hover:text-blue-600 hover:bg-blue-50"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-sm">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Leaderboard */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-6 border-b border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  Top Contributors
                </h3>
              </div>

              <div className="divide-y divide-gray-100">
                {leaderboardData.map((user, index) => (
                  <div
                    key={user.id}
                    className={`p-6 transition-all duration-300 cursor-pointer ${getRankBg(
                      user.rank,
                      user.isCurrentUser
                    )} ${hoveredUser === user.id ? "scale-102 shadow-md" : ""}`}
                    onMouseEnter={() => setHoveredUser(user.id)}
                    onMouseLeave={() => setHoveredUser(null)}
                  >
                    <div className="flex items-center gap-4">
                      {/* Rank */}
                      <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center">
                        {getRankIcon(user.rank)}
                      </div>

                      {/* Avatar */}
                      <div className="relative">
                        <img
                          src={user.avatar || "/placeholder.svg"}
                          alt={user.name}
                          className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-sm"
                        />
                        <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                          {user.level}
                        </div>
                      </div>

                      {/* User Info */}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-gray-800 text-lg">
                            {user.name}
                            {user.isCurrentUser && (
                              <span className="ml-2 text-blue-600 text-sm">
                                (Kamu)
                              </span>
                            )}
                          </h4>
                        </div>

                        <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                          <span className="flex items-center gap-1">
                            <Star className="w-4 h-4" />
                            {formatNumber(user.points)} poin
                          </span>
                          <span className="flex items-center gap-1">
                            <Target className="w-4 h-4" />
                            {user.completedChallenges} tantangan
                          </span>
                          <span className="flex items-center gap-1">
                            <Zap className="w-4 h-4" />
                            {user.streak} hari streak
                          </span>
                        </div>

                        {/* Badges */}
                        <div className="flex gap-1">
                          {user.badges.map((badge, badgeIndex) => (
                            <span
                              key={badgeIndex}
                              className="text-lg hover:scale-110 transition-transform cursor-pointer"
                              title="Badge"
                            >
                              {badge}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Points Display */}
                      <div className="text-right">
                        <div className="text-2xl font-bold text-gray-800">
                          #{user.rank}
                        </div>
                        <div className="text-sm text-gray-500">
                          Bergabung {user.joinDate}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Your Stats */}
            <div className="bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-6 border border-blue-200">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Statistik Kamu
              </h3>

              <div className="space-y-4">
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl font-bold text-gray-800 mb-1">
                    8,750
                  </div>
                  <div className="text-sm text-gray-600">Total Poin</div>
                </div>

                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl font-bold text-gray-800 mb-1">
                    #5
                  </div>
                  <div className="text-sm text-gray-600">
                    Peringkat Saat Ini
                  </div>
                </div>

                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl font-bold text-gray-800 mb-1">
                    15
                  </div>
                  <div className="text-sm text-gray-600">Hari Streak</div>
                </div>
              </div>

              <button className="w-full mt-4 bg-blue-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-blue-600 transition-colors">
                Lihat Profil Lengkap
              </button>
            </div>

            {/* Monthly Achievements */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-200">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Award className="w-5 h-5 text-yellow-500" />
                Pencapaian Bulan Ini
              </h3>

              <div className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="bg-gray-50 rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{achievement.icon}</span>
                      <div>
                        <h4 className="font-semibold text-gray-800 text-sm">
                          {achievement.title}
                        </h4>
                        <p className="text-xs text-gray-600">
                          {achievement.description}
                        </p>
                      </div>
                    </div>
                    <div className="ml-11">
                      <div className="font-bold text-blue-600 text-sm">
                        {achievement.winner}
                      </div>
                      <div className="text-xs text-gray-500">
                        {achievement.points}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-200">
              <h3 className="font-bold text-gray-800 mb-4">Quick Actions</h3>

              <div className="space-y-3">
                <button className="w-full bg-green-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-green-600 transition-colors text-sm">
                  Ikut Challenge Baru
                </button>
                <button className="w-full bg-purple-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-purple-600 transition-colors text-sm">
                  Share Pengalaman
                </button>
                <button className="w-full bg-orange-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-orange-600 transition-colors text-sm">
                  Undang Teman
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

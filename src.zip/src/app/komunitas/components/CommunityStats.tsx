"use client"
import { useState, useEffect } from "react"
import { Users, MessageCircle, Trophy, Recycle, TrendingUp, Globe, Heart, Target } from "lucide-react"

const statsData = [
  {
    icon: <Users className="w-8 h-8" />,
    value: "12.500+",
    label: "Member Aktif",
    description: "Komunitas yang terus berkembang setiap hari",
    color: "blue",
    growth: "+15%",
  },
  {
    icon: <MessageCircle className="w-8 h-8" />,
    value: "45.000+",
    label: "Diskusi & Tips",
    description: "Berbagi pengalaman dan solusi ramah lingkungan",
    color: "green",
    growth: "+23%",
  },
  {
    icon: <Trophy className="w-8 h-8" />,
    value: "8.900+",
    label: "Challenge Selesai",
    description: "Tantangan yang berhasil diselesaikan member",
    color: "yellow",
    growth: "+31%",
  },
  {
    icon: <Recycle className="w-8 h-8" />,
    value: "156",
    label: "Ton Sampah Didaur Ulang",
    description: "Dampak nyata dari aksi komunitas kita",
    color: "emerald",
    growth: "+42%",
  },
  {
    icon: <Globe className="w-8 h-8" />,
    value: "34",
    label: "Kota Terjangkau",
    description: "Jangkauan komunitas di seluruh Indonesia",
    color: "purple",
    growth: "+8%",
  },
  {
    icon: <Heart className="w-8 h-8" />,
    value: "98%",
    label: "Tingkat Kepuasan",
    description: "Member yang puas dengan komunitas",
    color: "pink",
    growth: "+2%",
  },
]

export default function CommunityStats() {
  const [countedStats, setCountedStats] = useState(statsData.map(() => 0))
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)

  useEffect(() => {
    const duration = 2000
    const interval = 50
    const steps = duration / interval

    statsData.forEach((stat, index) => {
      const target = Number.parseInt(stat.value.replace(/[^\d]/g, ""))
      if (isNaN(target)) return

      let step = 0
      const timer = setInterval(() => {
        step += 1
        const progress = Math.min(step / steps, 1)
        const currentValue = Math.floor(progress * target)

        setCountedStats((prev) => {
          const newCounts = [...prev]
          newCounts[index] = currentValue
          return newCounts
        })

        if (progress === 1) clearInterval(timer)
      }, interval)
    })
  }, [])

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: {
        bg: "bg-blue-50",
        text: "text-blue-600",
        border: "border-blue-200",
        iconBg: "bg-blue-500",
        gradient: "from-blue-100 to-blue-200",
      },
      green: {
        bg: "bg-green-50",
        text: "text-green-600",
        border: "border-green-200",
        iconBg: "bg-green-500",
        gradient: "from-green-100 to-green-200",
      },
      yellow: {
        bg: "bg-yellow-50",
        text: "text-yellow-600",
        border: "border-yellow-200",
        iconBg: "bg-yellow-500",
        gradient: "from-yellow-100 to-yellow-200",
      },
      emerald: {
        bg: "bg-emerald-50",
        text: "text-emerald-600",
        border: "border-emerald-200",
        iconBg: "bg-emerald-500",
        gradient: "from-emerald-100 to-emerald-200",
      },
      purple: {
        bg: "bg-purple-50",
        text: "text-purple-600",
        border: "border-purple-200",
        iconBg: "bg-purple-500",
        gradient: "from-purple-100 to-purple-200",
      },
      pink: {
        bg: "bg-pink-50",
        text: "text-pink-600",
        border: "border-pink-200",
        iconBg: "bg-pink-500",
        gradient: "from-pink-100 to-pink-200",
      },
    }
    return colorMap[color as keyof typeof colorMap] || colorMap.blue
  }

  return (
    <section className="w-full py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-100 px-4 py-2 rounded-full mb-6">
            <TrendingUp className="w-5 h-5 text-blue-600 animate-pulse" />
            <span className="text-blue-700 font-medium text-sm">Community Impact</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 leading-tight">
            Dampak <span className="text-blue-600">Komunitas</span> Kita
          </h1>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Angka-angka menakjubkan yang menunjukkan kekuatan komunitas dalam menciptakan perubahan positif untuk
            lingkungan
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {statsData.map((stat, index) => {
            const colors = getColorClasses(stat.color)
            const floatDelay = `${index * 0.3}s`

            return (
              <div
                key={index}
                className="group cursor-pointer transform hover:scale-105 transition-all duration-500"
                style={{
                  animation: `float 6s ease-in-out infinite ${floatDelay}`,
                }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div
                  className={`relative ${colors.bg} border-2 ${colors.border} rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-500`}
                >
                  {/* Background Pattern */}
                  <div className="absolute inset-0 opacity-5 rounded-3xl overflow-hidden">
                    <div className={`absolute -top-4 -right-4 w-20 h-20 ${colors.iconBg} rounded-full blur-xl`}></div>
                    <div className={`absolute -bottom-4 -left-4 w-16 h-16 ${colors.iconBg} rounded-full blur-xl`}></div>
                  </div>

                  <div className="relative z-10">
                    {/* Icon */}
                    <div
                      className={`w-16 h-16 ${colors.iconBg} rounded-2xl flex items-center justify-center mb-6 group-hover:rotate-12 group-hover:scale-110 transition-all duration-300`}
                    >
                      <div className="text-white">{stat.icon}</div>
                    </div>

                    {/* Growth Badge */}
                    <div className="absolute top-4 right-4">
                      <div className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        {stat.growth}
                      </div>
                    </div>

                    {/* Stats Number */}
                    <h3 className="text-4xl font-bold text-gray-800 mb-2 group-hover:text-gray-900 transition-colors duration-300">
                      {stat.value.includes("%") || stat.value.includes("Ton")
                        ? stat.value
                        : countedStats[index].toLocaleString() + (stat.value.includes("+") ? "+" : "")}
                    </h3>

                    {/* Label */}
                    <h4 className={`text-xl font-bold mb-3 ${colors.text} transition-colors duration-300`}>
                      {stat.label}
                    </h4>

                    {/* Description */}
                    <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                      {stat.description}
                    </p>

                    {/* Hover indicator */}
                    <div
                      className={`mt-6 w-full h-1 ${colors.iconBg} rounded-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left`}
                    ></div>
                  </div>

                  {/* Hover Effect Border */}
                  <div
                    className={`absolute inset-0 rounded-3xl border-2 ${colors.border} transition-opacity duration-300 ${hoveredIndex === index ? "opacity-100" : "opacity-0"}`}
                  ></div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Bottom Section */}
        <div className="mt-16 grid md:grid-cols-2 gap-8">
          {/* Join Community CTA */}
          <div className="bg-gradient-to-br from-blue-100 to-indigo-100 border border-blue-200 rounded-3xl p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-800">Bergabung Sekarang!</h3>
                <p className="text-blue-600 font-medium">Gratis dan mudah</p>
              </div>
            </div>

            <p className="text-gray-700 mb-6 leading-relaxed">
              Jadilah bagian dari komunitas yang membuat perbedaan nyata. Dapatkan akses ke forum, challenge, dan event
              eksklusif!
            </p>

            <button className="bg-blue-500 text-white px-8 py-3 rounded-full font-medium hover:bg-blue-600 transition-all duration-300 hover:scale-105">
              Daftar Sekarang
            </button>
          </div>

          {/* Quick Stats */}
          <div className="bg-white border border-gray-200 rounded-3xl p-8 shadow-sm">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
              <Target className="w-6 h-6 text-blue-600" />
              Aktivitas Hari Ini
            </h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <MessageCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <span className="font-medium text-gray-800">Post Baru</span>
                </div>
                <span className="font-bold text-gray-800">47</span>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Trophy className="w-5 h-5 text-yellow-600" />
                  </div>
                  <span className="font-medium text-gray-800">Challenge Selesai</span>
                </div>
                <span className="font-bold text-gray-800">23</span>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-purple-600" />
                  </div>
                  <span className="font-medium text-gray-800">Member Baru</span>
                </div>
                <span className="font-bold text-gray-800">12</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%,
          100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-8px);
          }
        }
      `}</style>
    </section>
  )
}

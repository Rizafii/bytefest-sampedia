"use client"
import { useState } from "react"
import { Trophy, Calendar, Users, Target, Clock, Star, Award, ChevronRight, Zap } from "lucide-react"

interface Challenge {
  id: number
  title: string
  description: string
  type: "weekly" | "monthly" | "special"
  difficulty: "Mudah" | "Sedang" | "Sulit"
  participants: number
  reward: string
  deadline: string
  progress: number
  icon: string
  color: string
  bgGradient: string
  isActive: boolean
}

const challenges: Challenge[] = [
  {
    id: 1,
    title: "Zero Waste Week Challenge",
    description: "Tantangan hidup tanpa sampah selama seminggu penuh. Dokumentasikan perjalananmu!",
    type: "weekly",
    difficulty: "Sulit",
    participants: 1247,
    reward: "Badge Eco Warrior + 500 Poin",
    deadline: "3 hari lagi",
    progress: 65,
    icon: "🌱",
    color: "green",
    bgGradient: "from-green-100 to-emerald-100",
    isActive: true,
  },
  {
    id: 2,
    title: "Recycle Art Contest",
    description: "Buat karya seni dari barang bekas dan menangkan hadiah menarik!",
    type: "monthly",
    difficulty: "Sedang",
    participants: 892,
    reward: "Hadiah Uang 1 Juta + Trophy",
    deadline: "2 minggu lagi",
    progress: 40,
    icon: "🎨",
    color: "purple",
    bgGradient: "from-purple-100 to-pink-100",
    isActive: true,
  },
  {
    id: 3,
    title: "Plastic Free Day",
    description: "Satu hari tanpa menggunakan plastik sama sekali. Siapa yang bisa?",
    type: "special",
    difficulty: "Mudah",
    participants: 2156,
    reward: "Badge Plastic Free + 200 Poin",
    deadline: "Besok",
    progress: 85,
    icon: "🚫",
    color: "red",
    bgGradient: "from-red-100 to-orange-100",
    isActive: true,
  },
  {
    id: 4,
    title: "Community Clean Up",
    description: "Bergabung dengan aksi bersih-bersih lingkungan di sekitar kamu",
    type: "weekly",
    difficulty: "Mudah",
    participants: 567,
    reward: "Badge Community Hero + 300 Poin",
    deadline: "5 hari lagi",
    progress: 30,
    icon: "🧹",
    color: "blue",
    bgGradient: "from-blue-100 to-cyan-100",
    isActive: true,
  },
]

export default function CommunityChallenge() {
  const [activeTab, setActiveTab] = useState<"all" | "weekly" | "monthly" | "special">("all")
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  const filteredChallenges =
    activeTab === "all" ? challenges : challenges.filter((challenge) => challenge.type === activeTab)

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      Mudah: "bg-green-100 text-green-700 border-green-200",
      Sedang: "bg-yellow-100 text-yellow-700 border-yellow-200",
      Sulit: "bg-red-100 text-red-700 border-red-200",
    }
    return colors[difficulty as keyof typeof colors]
  }

  const getTypeColor = (type: string) => {
    const colors = {
      weekly: "bg-blue-100 text-blue-700 border-blue-200",
      monthly: "bg-purple-100 text-purple-700 border-purple-200",
      special: "bg-orange-100 text-orange-700 border-orange-200",
    }
    return colors[type as keyof typeof colors]
  }

  const getColorClasses = (color: string) => {
    const colorMap = {
      green: {
        bg: "bg-green-500",
        text: "text-green-600",
        light: "bg-green-100",
        border: "border-green-200",
      },
      purple: {
        bg: "bg-purple-500",
        text: "text-purple-600",
        light: "bg-purple-100",
        border: "border-purple-200",
      },
      red: {
        bg: "bg-red-500",
        text: "text-red-600",
        light: "bg-red-100",
        border: "border-red-200",
      },
      blue: {
        bg: "bg-blue-500",
        text: "text-blue-600",
        light: "bg-blue-100",
        border: "border-blue-200",
      },
    }
    return colorMap[color as keyof typeof colorMap] || colorMap.blue
  }

  return (
    <section className="w-full py-20 px-4 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-100 px-4 py-2 rounded-full mb-6">
            <Trophy className="w-5 h-5 text-blue-600 animate-pulse" />
            <span className="text-blue-700 font-medium text-sm">Community Challenges</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 leading-tight">
            Tantangan <span className="text-blue-600">Komunitas</span>
          </h1>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed mb-8">
            Bergabunglah dengan tantangan seru dan raih poin serta badge eksklusif! Bersama-sama kita ciptakan dampak
            positif untuk lingkungan.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-2xl p-2 shadow-sm border border-gray-200">
            <div className="flex gap-2">
              {[
                { id: "all", label: "Semua", icon: Target },
                { id: "weekly", label: "Mingguan", icon: Calendar },
                { id: "monthly", label: "Bulanan", icon: Star },
                { id: "special", label: "Spesial", icon: Zap },
              ].map((tab) => {
                const Icon = tab.icon
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                      activeTab === tab.id
                        ? "bg-blue-500 text-white shadow-lg"
                        : "text-gray-600 hover:text-blue-600 hover:bg-blue-50"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-sm">{tab.label}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>

        {/* Challenges Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredChallenges.map((challenge, index) => {
            const colors = getColorClasses(challenge.color)
            return (
              <div
                key={challenge.id}
                className="group cursor-pointer transform hover:scale-105 transition-all duration-300"
                onMouseEnter={() => setHoveredCard(challenge.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <div
                  className={`bg-gradient-to-br ${challenge.bgGradient} border-2 ${colors.border} rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div className="flex items-center gap-4">
                      <div className="text-4xl">{challenge.icon}</div>
                      <div>
                        <div className="flex gap-2 mb-2">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(challenge.difficulty)}`}
                          >
                            {challenge.difficulty}
                          </span>
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-medium border ${getTypeColor(challenge.type)}`}
                          >
                            {challenge.type === "weekly"
                              ? "Mingguan"
                              : challenge.type === "monthly"
                                ? "Bulanan"
                                : "Spesial"}
                          </span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-800 group-hover:text-gray-900 transition-colors">
                          {challenge.title}
                        </h3>
                      </div>
                    </div>
                    {challenge.isActive && <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>}
                  </div>

                  {/* Description */}
                  <p className="text-gray-700 mb-6 leading-relaxed">{challenge.description}</p>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Users className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-600">Peserta</span>
                      </div>
                      <div className="text-lg font-bold text-gray-800">{challenge.participants.toLocaleString()}</div>
                    </div>
                    <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-600">Deadline</span>
                      </div>
                      <div className="text-lg font-bold text-gray-800">{challenge.deadline}</div>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Progress</span>
                      <span className="text-sm font-bold text-gray-800">{challenge.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${colors.bg} transition-all duration-500`}
                        style={{ width: `${challenge.progress}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Reward */}
                  <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-white/50 mb-6">
                    <div className="flex items-center gap-2 mb-2">
                      <Award className="w-4 h-4 text-yellow-600" />
                      <span className="text-sm font-medium text-gray-700">Hadiah</span>
                    </div>
                    <p className="text-sm font-bold text-gray-800">{challenge.reward}</p>
                  </div>

                  {/* Action Button */}
                  <button
                    className={`w-full ${colors.bg} text-white py-3 px-6 rounded-xl font-medium hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2 group-hover:scale-105`}
                  >
                    <span>Ikut Tantangan</span>
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            )
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-100 to-indigo-100 border border-blue-200 rounded-3xl p-8 max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-4">
              <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center">
                <Trophy className="w-8 h-8 text-white" />
              </div>
            </div>

            <h3 className="text-2xl font-bold text-gray-800 mb-4">Punya Ide Tantangan Baru?</h3>

            <p className="text-lg text-gray-700 leading-relaxed max-w-2xl mx-auto mb-6">
              Usulan tantangan terbaikmu bisa menjadi tantangan resmi komunitas! Bagikan ide kreatifmu dan menangkan
              hadiah spesial.
            </p>

            <button className="bg-blue-500 text-white px-8 py-3 rounded-full font-medium hover:bg-blue-600 transition-all duration-300 hover:scale-105">
              Usulkan Tantangan
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
